# Leadboost

## Sistema de Login com Firebase Authentication ##

Este código já está conectado ao Firebase e está pronto para integrar-se ao banco de dados e outras ferramentas. A integração foi realizada especificamente com a ferramenta Firebase Authentication para a página de login.

# Login:
# Senha:

Login e senha para teste.
