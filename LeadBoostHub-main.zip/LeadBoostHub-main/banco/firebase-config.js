const firebaseConfig = {
  apiKey: "AIzaSyBLOXvADaAUqIPn6MxVT2RBSjzUE7ZSEzE",
  authDomain: "leadboost-b.firebaseapp.com",
  projectId: "leadboost-b",
  storageBucket: "leadboost-b.appspot.com",
  messagingSenderId: "597873909881",
  appId: "1:597873909881:web:73524556113e6e453af4a8",
  measurementId: "G-TGMQYHTHV9"
};
// Inicializa o Firebase
firebase.initializeApp(firebaseConfig);

